package com.depannage.dz;
import android.app.*; import android.os.*; import android.widget.*; import android.view.*;
public class MainActivity extends Activity {
 TextView result;
 public void onCreate(Bundle b){super.onCreate(b); setContentView(R.layout.activity_main);
  result=findViewById(R.id.result);
  findViewById(R.id.diagnose).setOnClickListener(v->show("تشخيص العطل","اختر العرض الذي تلاحظه في سيارتك.\n\n• المحرك لا يشتغل\n• ارتفاع الحرارة\n• ضعف التسارع\n• اهتزاز المحرك\n• دخان من العادم\n\nهذه النسخة هي الأساس، وسنضيف قاعدة التشخيص التفصيلية إليها."));
  findViewById(R.id.obd).setOnClickListener(v->show("OBD / Scanner","قسم أكواد الأعطال جاهز للإضافة.\nسنضيف البحث عن الكود وشرح السبب والفحص المقترح."));
  findViewById(R.id.parts).setOnClickListener(v->show("قطع السيارة","قسم قطع السيارة جاهز.\nسنضيف أسماء القطع ووظيفتها وأعراض تلفها."));
  findViewById(R.id.help).setOnClickListener(v->show("المساعدة","سيتم هنا إضافة خطوات آمنة للتعامل مع العطل وطلب المساعدة."));
 }
 void show(String t,String m){new AlertDialog.Builder(this).setTitle(t).setMessage(m).setPositiveButton("حسنًا",null).show();}
}
