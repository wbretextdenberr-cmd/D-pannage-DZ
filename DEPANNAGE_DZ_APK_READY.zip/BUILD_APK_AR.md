# إخراج APK

1. أنشئ مستودع GitHub جديدًا.
2. ارفع كامل محتويات هذا المشروع.
3. افتح تبويب Actions.
4. شغّل Build DÉPANNAGE.DZ APK بواسطة Run workflow.
5. بعد انتهاء البناء افتح نتيجة التشغيل ونزّل artifact باسم DEPANNAGE-DZ-debug-apk.
6. فك الضغط عن artifact وستجد app-debug.apk، ثم ثبّته على هاتف Android.

هذا البناء لا يعتمد على Gemini.
